<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Articles List</title>
    <style>
        .booking{
            text-align:center;
        }
    </style>
</head>
<body>
    @extends("layouts.app")
    
    @section("content")
                                <div class="container">
                                {{ $articles->links() }}

                    <div class="card mb-2">
                    <div class="card-body">
                    <div class="card-subtitle mb-2 text-muted small">
                    </div>
                    <div class="table-responsive-lg">

                        <table  class="table table-striped">
                            <thead>
                                
                                <tr>
                                    <th >No</th>
                                    <th >Name</th>
                                    <th>DOB</th>
                                <th >Age</th>
                                <th >nrc</th>
                                <th >1st Date Of Vaccination</th>
                                <th >2nd Date Of Vaccination</th>
                                <th>Booster Date Of Vaccination</th>
                                <th ></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($articles as $key =>$article)
                        <tr>
                            <td scope="row">{{ $key+1 }}</td>
                            <td>{{ $article->name }}</td>
                            <td>{{ $article->date_of_birth }}</td>
                            <td>{{ $article->Age }}</td>
                            <td>{{ $article->nrc }}</td>
                            <td>{{date('d-m-Y', strtotime($article->first_vaccination_appointment));}}</td>
                            <td>{{date('d-m-Y', strtotime($article->second_vaccination_appointment));}}</td>
                            <td>{{date('d-m-Y', strtotime($article->booster_vaccination_appointment));}}</td>
                            <td>
                                <a href="{{ route('generate',$article->id) }}" class="btn btn-outline-primary">View</a>
                                </td>
                                <td>
                                    <a class="btn btn-outline-dark"
                                    href="{{ url("/articles/edit/$article->id") }}">
                                    Edit
                                </a>
                            </td>
                            <td>
                                <a class="btn btn-warning" 
                                href="{{ url("/articles/detail/$article->id") }}">
                                User View &raquo;
                            </a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>

        </div> 
        <h2 class="booking">Booking</h2> 
        <table  class="table table-striped">
                            <thead>
                                
                                <tr>
                                    <th >No</th>
                                    <th >Name</th>
                                <th >Age</th>
                                <th >Appointment Date</th>
                                <th ></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($bookings as $key =>$booking)
                        <tr>
                            <td scope="row">{{ $key+1 }}</td>
                            <td>{{ $booking->name }}</td>
                            <td>{{ $booking->age }}</td>
                            <td>{{date('d-m-Y', strtotime($booking->appointment));}}</td>
                            <td> <a class="btn btn-danger"
                            href="{{ url("/bookings/delete/$booking->id") }}">
                            Delete
                            </a>
                            </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div> 
    </div>
</div>
            @endsection
        </body>
        </html>